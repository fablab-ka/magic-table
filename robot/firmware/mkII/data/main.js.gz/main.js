if (!String.prototype.padStart) {
  String.prototype.padStart = function padStart(targetLength, padString) {
    targetLength = targetLength >> 0; //truncate if number, or convert non-number to 0;
    padString = String(typeof padString !== "undefined" ? padString : " ");
    if (this.length >= targetLength) {
      return String(this);
    } else {
      targetLength = targetLength - this.length;
      if (targetLength > padString.length) {
        padString += padString.repeat(targetLength / padString.length); //append to original to ensure we are longer than needed
      }
      return padString.slice(0, targetLength) + String(this);
    }
  };
}

var rainbowEnable = false;
var connection = new WebSocket("ws://" + location.hostname + ":81/", [
  "arduino"
]);
connection.onopen = function() {
  connection.send("Connect " + new Date());
};
connection.onerror = function(error) {
  console.log("WebSocket Error ", error);
};
connection.onmessage = function(e) {
  console.log("Server: ", e.data);
};
connection.onclose = function() {
  console.log("WebSocket connection closed");
};

function moveLeft() {
  sendMovement("1");
}
function moveRight() {
  sendMovement("2");
}
function moveForward() {
  sendMovement("3");
}
function moveBackward() {
  sendMovement("4");
}
function stop() {
  sendMovement("0");
}
function sendPosition() {
  var positionX = document.getElementById("positionx").value * 1;
  var positionY = document.getElementById("positiony").value * 1;
  var rotation = document.getElementById("rotation").value * 1;

  var posX = positionX.toString(16).padStart(2, "0");
  var posY = positionY.toString(16).padStart(2, "0");
  var rot = rotation.toString(16).padStart(2, "0");

  var commandstr = ">" + posX + " " + posY + " " + rot;
  console.log("Command: " + commandstr);
  connection.send(commandstr);
}
function sendMovement(dir) {
  var velocity = document.getElementById("velocity").value;
  var amountValue = Math.floor(
    document.getElementById("amount").value ** 2 / 255
  );

  var amount = amountValue.toString(16).padStart(2, "0");

  var commandstr = "#" + dir + velocity + ":" + amount;
  console.log("Command: " + commandstr);
  connection.send(commandstr);
}
